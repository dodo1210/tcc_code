function display(a)

display(mirdata(a));

display_figure(a);