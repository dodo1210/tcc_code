function displayer(a,axis,song)

displayer(mirdata(a),axis,song);

display_figure(a);