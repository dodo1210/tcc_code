function displayer(s,axis,song)
% SCALAR/DISPLAY display the values of a scalar object in MIRPLAYER

display_figure(s,axis,song);