function displayer(d,axis,song)
% MIRDATA/DISPLAYER display of a MIR data in MIRPLAYER

mirdisplay(d,inputname(1),axis,song);