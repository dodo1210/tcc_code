# def test_generate_pcd():
#     pitch_track = np.loadtxt('pitch_track.txt')
#     pd = mF.generate_pd(pitch_track)
#     pcd = pd = mF.generate_pcd(pd)
#     test_pd = PitchDistribution.load('test_pd')
#     test_pcd = PitchDistribution.load('test_pcd')
#     assert ((pd == test_pd) and (pcd == test_pcd))
